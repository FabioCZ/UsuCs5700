﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Model;

namespace Cs5700Hw4.Lib.Solver
{
    public abstract class TemplatedPuzzleSolver : IPuzzleSolver
    {
        /// <summary>
        /// Template method
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public PuzzleSolution Solve(Puzzle input)
        {
            var solution = new PuzzleSolution { OriginalPuzzle = input };
            if (ValidateInitialState(input))
            {
                solution = SolveInternal(input);
                if (solution.Solutions.Any(singleSolution => !ValidateSolution(singleSolution)))
                {
                    solution.SolutionState = SolutionState.BadSolutionProduced;
                    return solution;
                }
                solution.SolutionState = solution.Solutions.Count > 1
                    ? SolutionState.MultipleSolutions
                    : solution.Solutions.Count == 1 ? SolutionState.OneSolution : SolutionState.Unsolvable;
            }
            else
            {
                solution.SolutionState = SolutionState.InvalidPuzzle;
            }
            return solution;
        }

        protected abstract PuzzleSolution SolveInternal(Puzzle input);

        private bool ValidateInitialState(Puzzle input) => input.IsValidPuzzle(allowEmpty: true);

        private bool ValidateSolution(Puzzle solution) => solution.IsValidPuzzle(allowEmpty: false);
    }
}
