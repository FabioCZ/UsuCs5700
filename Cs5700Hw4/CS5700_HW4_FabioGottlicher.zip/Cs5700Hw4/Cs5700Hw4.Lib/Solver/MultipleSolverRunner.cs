﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Model;

namespace Cs5700Hw4.Lib.Solver
{
    public class MutliAlgorithmPuzzleSolver : IPuzzleSolver
    {
        private readonly IReadOnlyList<TemplatedPuzzleSolver> solvers = new List<TemplatedPuzzleSolver>()
        {
            new BackTrackingPuzzleSolver(),
            new BruteForcePuzzleSolver()
        };
        public PuzzleSolution Solve(Puzzle input)
        {
            var solutions = solvers.Select(solver => solver.Solve(input)).ToList();
            return PuzzleSolutionMerger.Merge(solutions.ToArray());
        }
    }
}
