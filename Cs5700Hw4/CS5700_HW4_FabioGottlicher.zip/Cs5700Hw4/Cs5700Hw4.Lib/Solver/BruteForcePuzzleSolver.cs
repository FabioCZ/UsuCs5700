﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Model;

namespace Cs5700Hw4.Lib.Solver
{
    public class BruteForcePuzzleSolver : TemplatedPuzzleSolver
    {
        private Puzzle workingCopy;
        protected override PuzzleSolution SolveInternal(Puzzle input)
        {
            workingCopy = new Puzzle(input);
            if (SolveInternalHelper())
            {
                var sol = new List<Puzzle> { workingCopy };
                return new PuzzleSolution()
                {
                    OriginalPuzzle = input,
                    Solutions = sol,
                    SolutionState = SolutionState.OneSolution
                };
            }
            else
            {
                return new PuzzleSolution()
                {
                    OriginalPuzzle = input,
                    Solutions = null,
                    SolutionState = SolutionState.Unsolvable
                };
            }
        }

        private bool SolveInternalHelper()
        {
            
            var y = 0;
            var x = 0;
            var found = false;
            for (y = 0; y < workingCopy.Size; y++)
            {
                for (x = 0; x < workingCopy.Size; x++)
                {
                    if (workingCopy.Board[y, x].CurrentValue == Cell.Empty)
                    {
                        found = true;
                        break;
                    }
                }
                if (found) break;
            }
            if (!found) return true;

            bool[] digits = new bool[workingCopy.Size + 2];
            for (int i = 0; i < workingCopy.Size; i++)
            {
                digits[workingCopy.Board[y,i].CurrentValueOrdinal] = true;
                digits[workingCopy.Board[i,x].CurrentValueOrdinal] = true;
            }
            var sizeSqrt = Convert.ToInt32(Math.Sqrt(workingCopy.Size));
            var by = sizeSqrt*(y/sizeSqrt);
            var bx = sizeSqrt * (x / sizeSqrt);
            for (int i = 0; i < sizeSqrt; i++)
                for (int j = 0; j < sizeSqrt; j++)
                    digits[workingCopy.Board[by + i,bx + j].CurrentValueOrdinal] = true;

            for (int i = 1; i <= workingCopy.Size; i++)
            {
                if (!digits[i])
                {
                    workingCopy.Board[y,x].CurrentValueOrdinal = i;
                    if (SolveInternalHelper())
                        return true;
                    workingCopy.Board[y, x].CurrentValueOrdinal = 0;
                }
            }
            return false;
        }
    }
}
