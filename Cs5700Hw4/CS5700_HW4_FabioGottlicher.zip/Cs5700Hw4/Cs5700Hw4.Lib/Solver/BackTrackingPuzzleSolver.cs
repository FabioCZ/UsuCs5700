﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Model;

namespace Cs5700Hw4.Lib.Solver
{
    //Inspired by https://bob-carpenter.github.io/games/sudoku/java_sudoku.html
    public class BackTrackingPuzzleSolver : TemplatedPuzzleSolver
    {
        private Puzzle workingCopy;
        protected override PuzzleSolution SolveInternal(Puzzle input)
        {
            workingCopy = new Puzzle(input);
            if (SolveInternalHelper(0, 0))
            {
                Debugging.DebugPrint.PrintPuzzle(workingCopy);
                var sol = new List<Puzzle> {workingCopy};
                return new PuzzleSolution()
                {
                    OriginalPuzzle = input,
                    Solutions = sol,
                    SolutionState = SolutionState.OneSolution
                };
            }
            else
            {
                return new PuzzleSolution()
                {
                    OriginalPuzzle = input,
                    Solutions = null,
                    SolutionState = SolutionState.Unsolvable
                };
            }
        }

        private bool SolveInternalHelper(int i, int j)
        {
            if (i == workingCopy.Size)
            {
                i = 0;
                if (++j == workingCopy.Size)
                {
                    return true;
                }
            }
            if (workingCopy.Board[i, j].CurrentValue != Cell.Empty)
            {
                return SolveInternalHelper(i + 1, j);
            }

            foreach (var val in workingCopy.Symbols)
            {
                if (workingCopy.IsUniqueInRowColSquare(j,i, val))
                {
                    workingCopy.Board[i, j].CurrentValue = val;
                    if (SolveInternalHelper(i + 1, j))
                    {
                        return true;
                    }
                }
            }
            workingCopy.Board[i, j].CurrentValue = Cell.Empty;
            return false;
        }
    }
}
