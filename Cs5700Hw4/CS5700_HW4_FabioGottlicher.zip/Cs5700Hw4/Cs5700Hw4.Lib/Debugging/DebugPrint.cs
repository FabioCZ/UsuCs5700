﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Model;

namespace Cs5700Hw4.Lib.Debugging
{
    public static class DebugPrint
    {
        public static void PrintPuzzle(Puzzle puzzle)
        {
            for (var i = 0; i < puzzle.Size; i++)
            {
                for (var j = 0; j < puzzle.Size; j++)
                {
                    Console.Write(puzzle.Board[i, j] + " ");
                }
                Console.Write(Environment.NewLine);
            }
            Console.Write(Environment.NewLine);
        }
    }
}
