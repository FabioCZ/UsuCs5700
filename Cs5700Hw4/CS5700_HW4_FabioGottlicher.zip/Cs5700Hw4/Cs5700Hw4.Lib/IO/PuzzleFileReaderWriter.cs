﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Model;

namespace Cs5700Hw4.Lib.IO
{
    public class PuzzleFileReaderWriter
    {
        private readonly IPuzzleConverter converter = new PlainTextPuzzleConverter();
        public Puzzle Read(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                Console.WriteLine("Input filename must be specified");
                throw new ArgumentException("Input filename must be specified");
            }
            return converter.DeSerialize(File.ReadAllText(fileName));
        }

        public void Write(PuzzleSolution solution, string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                Console.WriteLine("Output filename must be specified");
                throw new ArgumentException("Output filename must be specified");
            }
            File.WriteAllText(fileName,converter.Serialize(solution));
        }

    }
}
