﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Model;

namespace Cs5700Hw4.Lib.IO
{
    public class PlainTextPuzzleConverter : IPuzzleConverter
    {
        public Puzzle DeSerialize(string puzzleData)
        {
            var lines = Regex.Split(puzzleData, Environment.NewLine);
            if (lines.Length == 0)
            {
                return null;
            }
            var size = Convert.ToInt32(lines[0]);
            var symbols = lines[1].Split(' ').ToList();
            var board = new Cell[size, size];
            for (var i = 0; i < size; i++)
            {
                var currLine = lines[i + 2].Split(' ');
                for (var j = 0; j < size; j++)
                {
                    board[i,j] = new Cell(symbols,currLine[j]);
                }
            }

            //make a read only collection so that no one messes with the Symbols
            return new Puzzle(board,symbols.AsReadOnly(), size);
        }

        public string Serialize(PuzzleSolution solution)
        {
            var sb = new StringBuilder();
            switch (solution.SolutionState)
            {
                case SolutionState.Unknown:
                    sb.AppendLine("Unknown state");
                    break;
                case SolutionState.OneSolution:
                    AppendPuzzle(sb,solution.Solutions[0]);
                    break;
                case SolutionState.MultipleSolutions:
                    AppendPuzzle(sb, solution.OriginalPuzzle);
                    sb.AppendLine("Multiple Solutions");
                    foreach (var sol in solution.Solutions)
                    {
                        AppendPuzzle(sb,sol);
                    }
                    break;
                case SolutionState.BadSolutionProduced:
                    sb.AppendLine("Internal Error - invalid solutuion produced");
                    break;
                case SolutionState.Unsolvable:
                    AppendPuzzle(sb, solution.OriginalPuzzle);
                    sb.AppendLine("Unsolvable");
                    break;
                case SolutionState.InvalidPuzzle:
                    AppendPuzzle(sb,solution.OriginalPuzzle);
                    sb.AppendLine("Bad Puzzle");
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
            return sb.ToString();
        }

        private void AppendPuzzle(StringBuilder sb, Puzzle puzzle)
        {
            sb.AppendLine(puzzle.Size.ToString());
            sb.AppendLine(string.Join(" ", puzzle.Symbols));
            for (var i = 0; i < puzzle.Size; i++)
            {
                for (var j = 0; j < puzzle.Size; j++)
                {
                    sb.AppendFormat("{0} ", puzzle.Board[i, j]);
                }
                sb.Append(Environment.NewLine);
            }
        }
    }
}
