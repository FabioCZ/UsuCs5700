﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cs5700Hw4.Lib.Model
{
    public static class PuzzleSolutionMerger
    {
        public static PuzzleSolution Merge(params PuzzleSolution[] list)
        {
            if (list.Length == 0) return null;
            var solution = list[0];
            if (list.Length == 1) return solution;
            for (var i = 1; i < list.Length; i++)
            {
                foreach (var thisListSol in list[i].Solutions)
                {
                    var alreadyPresent = false;
                    foreach (var existingSolution in solution.Solutions)
                    {
                        if (Puzzle.AreSameSolutions(existingSolution, thisListSol))
                        {
                            alreadyPresent = true;
                        }
                    }
                    if (!alreadyPresent)
                    {
                        solution.Solutions.Add(thisListSol);
                    }
                }
            }

            if (solution.Solutions.Count > 1)
            {
                solution.SolutionState = SolutionState.MultipleSolutions;
            }
            return solution;
        }
    }
}
