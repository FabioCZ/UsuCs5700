﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cs5700Hw4.Lib.Solver;

namespace Cs5700Hw4.Lib.Model
{
    public enum SolutionState { Unknown, OneSolution, MultipleSolutions, BadSolutionProduced, Unsolvable, InvalidPuzzle }

    public class PuzzleSolution
    {
        public Puzzle OriginalPuzzle { get; set; }

        public List<Puzzle> Solutions { get; set; }

        public SolutionState SolutionState { get; set; }

        public PuzzleSolution()
        {
            Solutions = new List<Puzzle>();
            SolutionState =  SolutionState.Unknown;
        }
    }
}
