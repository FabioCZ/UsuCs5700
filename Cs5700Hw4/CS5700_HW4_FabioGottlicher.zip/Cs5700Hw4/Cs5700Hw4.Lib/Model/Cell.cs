﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cs5700Hw4.Lib.Model
{
    public class Cell
    {
#region static values
        public static readonly string Empty = "-";
#endregion
        public IReadOnlyList<string> ValidValues { get; private set; }

        private string currValue = Cell.Empty;
        public string CurrentValue
        {
            get { return currValue; }
            set
            {
                if (ValidValues.Contains(value) || value == Cell.Empty)
                {
                    currValue = value;
                }
            }
        }

        public int CurrentValueOrdinal
        {
            get
            {
                var toRet = Array.IndexOf(ValidValues.ToArray(), CurrentValue);
                return toRet == -1 ? 0 : toRet +1;
            }
            set {
                CurrentValue = value == 0 ? Empty : ValidValues[value-1];
            }
        }

        public Cell(IReadOnlyList<string> validValues, string currValue)
        {
            ValidValues = validValues;
            CurrentValue = currValue;
        }

        public override string ToString()
        {
            return currValue;
        }
    }
}
