﻿namespace Cs5700Hw1.Serialization
{
    public enum FileType
    {
        Json,
        Xml
    }
}